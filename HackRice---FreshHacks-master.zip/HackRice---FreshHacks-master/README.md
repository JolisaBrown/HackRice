# HackRice---FreshHacks

Expenditure Ender

This fresh new solution is intended to provide support for people who have trouble keeping a budget.
FEATURES:
    Immediate texts upon transaction
    Simple categorization interface
    Easy to track budget categories
    Lifelong skills gained from improved financial competency

After creating an account, a user has to simply put in information for how much they intend to spend in each given category amongst a list
including food, gas, clothing, and other similar categories. The account would be linked to the user's credit card, so when a user makes a 
purchase with said card, the app is immediately notified of the transaction. (NOTE - credit card purchases are simulated, no actual credit
card data is currently used) After a transaction occurs, the application texts a link to the user, providing them with access to mark down
the category in which they have just spent money. Personal spending categories are displayed so a user can quickly and easily identify
which categories they may be overspending, leading to personal accountability and financial stability. (not yet displayed, feature coming soon)
